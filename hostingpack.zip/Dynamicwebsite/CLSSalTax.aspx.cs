﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace cmspprj
{
    public partial class CLSSalTax : System.Web.UI.Page
    {

        string cnStr = null;

        SqlConnection SCnn = null;
        SqlCommand SCmd = null;
        SqlDataAdapter SDa = null;

        DataSet ds = null;
        DataTable dt = null;

        string qryIns = null, qryUpd = null, qrydel = null;
        string qrysela =null, qryselb = null;

        public void uRefreshGridView()
        {
            try
            {
                ds = new DataSet();

                SCmd = new SqlCommand(qrysela, SCnn);
                SDa = new SqlDataAdapter(SCmd);

                SDa.Fill(ds, "esaltaxtbl");
                dt = ds.Tables["esaltaxtbl"];

                gvEAList.DataSource = dt;
                gvEAList.DataBind();


            }
            catch(Exception ex)
            {
                tbxmsg.Text = "Err.: " + ex.Message;
            }
        }


        public void uRunDMLQuery(String dmLst)
        {
            try
            {
                if (dmLst == "insert")
                {
                    SCmd = new SqlCommand(qryIns, SCnn);
                    SCmd.Parameters.AddWithValue("@ename", tbxname.Text);
                    SCmd.Parameters.AddWithValue("@esal", tbxsal.Text);
                }
                else if (dmLst == "update")
                {
                    SCmd = new SqlCommand(qryUpd, SCnn);
                    SCmd.Parameters.AddWithValue("@eid", tbxid.Text);
                    SCmd.Parameters.AddWithValue("@ename", tbxname.Text);
                    SCmd.Parameters.AddWithValue("@esal", tbxsal.Text);
                }
                else if (dmLst == "delete")
                {
                    SCmd = new SqlCommand(qrydel, SCnn);
                    SCmd.Parameters.AddWithValue("@eid", tbxid.Text);

                }

                Lnkbtncancel_Click(null, null);

                if (SCmd.ExecuteNonQuery() > 0)
                {
                    uRefreshGridView();
                    tbxmsg.Text = "Affected 1 row";
                }

            }
            catch(Exception ex)
            {
                tbxmsg.Text = "Err.: " + ex.Message;
            }
        }

        protected void gvEAList_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbxid.Text = gvEAList.DataKeys[gvEAList.SelectedRow.RowIndex].Value + "";
            LnkbtnFind_Click(null, null);

        }

        protected void gvEAList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvEAList.PageIndex = e.NewPageIndex;

            uRefreshGridView();
        }

        protected void LnkbtnFind_Click(object sender, EventArgs e)
        {
            try
            {
                SCmd = new SqlCommand(qryselb, SCnn);
                SCmd.Parameters.AddWithValue("@eid", tbxid.Text);
                SDa = new SqlDataAdapter(SCmd);

                ds = new DataSet();
                SDa.Fill(ds, "esaltaxtbl");
                dt = ds.Tables["esaltaxtbl"];

                if (dt.Rows.Count != 1)
                {
                    Lnkbtncancel_Click(null, null);
                    return;
                }

                tbxname.Text = dt.Rows[0]["ename"] + "";
                tbxsal.Text = dt.Rows[0]["esal"] + "";
                tbxtax10.Text = dt.Rows[0]["tax10"] + "";
                tbxtax20.Text = dt.Rows[0]["tax20"] + "";
                tbxtax30.Text = dt.Rows[0]["tax30"] + "";
                tbxtaxtot.Text = dt.Rows[0]["ttax"] + "";
                tbxnpay.Text = dt.Rows[0]["npay"] + "";

                tbxmsg.Text = "Affected 1 row";
            }
            catch(Exception ex)
            {
                tbxmsg.Text = "Err.: " + ex.Message;
            }
            
        }

        protected void Lnkbtnadd_Click(object sender, EventArgs e)
        {
            uRunDMLQuery("insert");


        }

        protected void LnkbtnEdit_Click(object sender, EventArgs e)
        {
            string eid = tbxid.Text;
            uRunDMLQuery("update");
            tbxid.Text = eid;
            LnkbtnFind_Click(null, null);
        }

        protected void LnkbtnErase_Click(object sender, EventArgs e)
        {
            uRunDMLQuery("delete");
        }

        protected void tbxmsg_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            qryIns = "Insert into esaltaxtbl";
            qryIns += " (ename,esal)";
            qryIns += " values";
            qryIns += " (@ename,@esal)";

            qryUpd = "Update esaltaxtbl set";
            qryUpd += " ename=@ename,";
            qryUpd += " esal=@esal";
            qryUpd += " where eid=@eid";

            qrydel = "Delete from esaltaxtbl";
            qrydel += " where eid=@eid";

            qrysela = "Select * from esaltaxtbl";

            qryselb = "Select * from esaltaxtbl";
            qryselb += " where eid =@eid";

            cnStr = "Data Source=.;";
            cnStr += "Initial Catalog = cmrdb;";
            cnStr += "Integrated Security=true;";

            try
            {
                SCnn = new SqlConnection(cnStr);
                SCnn.Open();

                uRefreshGridView();

            }
            catch(Exception ex)
            {
                tbxmsg.Text = "Err.: " + ex.Message;
            }

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Lnkbtncancel_Click(object sender, EventArgs e)
        {
            tbxid.Text = null;
            tbxname.Text = null;
            tbxsal.Text = null;
            tbxtax10.Text = null;
            tbxtax20.Text = null;
            tbxtax30.Text = null;
            tbxtaxtot.Text = null;
            tbxnpay.Text = null;

            tbxmsg.Text = null;
        }

    }
}