﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace cmspprj.Dynamicwebsite
{

    public partial class webExamdy : System.Web.UI.Page
    {
        string cnStr = null;

        SqlConnection SCnn = null;
        SqlCommand SCmd = null;
        SqlDataAdapter SDa = null;

        DataSet ds = null;
        DataTable dt = null;

        string qryIns = null, qryUpd = null, qrydel = null;
        string qrysela = null, qryselb = null;
        public void uRefreshGridView()
        {
            try
            {
                ds = new DataSet();

                SCmd = new SqlCommand(qrysela, SCnn);
                SDa = new SqlDataAdapter(SCmd);

                SDa.Fill(ds, "ertbl");
                dt = ds.Tables["ertbl"];

                gvEAList.DataSource = dt;
                gvEAList.DataBind();


            }
            catch (Exception ex)
            {
                tbxmsg.Text = "Err.: " + ex.Message;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            qryIns = "Insert into ertbl";
            qryIns += " (sname,m1,m2)";
            qryIns += " values";
            qryIns += " (@sname,@m1,@m2)";

            qryUpd = "Update ertbl set";
            qryUpd += " sname=@sname,";
            qryUpd += " m1=@m1";
            qryUpd += " m2=@m2";
            qryUpd += " where rno=@rno";

            qrydel = "Delete from ertbl";
            qrydel += " where rno=@rno";

            qrysela = "Select * from ertbl";

            qryselb = "Select * from ertbl";
            qryselb += " where rno =@rno";

            cnStr = "Data Source=.;";
            cnStr += "Initial Catalog = midb;";
            cnStr += "Integrated Security=true;";

            try
            {
                SCnn = new SqlConnection(cnStr);
                SCnn.Open();

                uRefreshGridView();

            }
            catch (Exception ex)
            {
                tbxmsg.Text = "Err.: " + ex.Message;
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnfind_Click(object sender, EventArgs e)
        {
            try
            {
                SCmd = new SqlCommand(qryselb, SCnn);
                SCmd.Parameters.AddWithValue("@rno", tbxid.Text);
                SDa = new SqlDataAdapter(SCmd);

                ds = new DataSet();
                SDa.Fill(ds, "ertbl");
                dt = ds.Tables["ertbl"];

                if (dt.Rows.Count != 1)
                {
                    btncnl_Click(null, null);
                    return;
                }

                tbxnae.Text = dt.Rows[0]["name"] + "";
                tbxm1.Text = dt.Rows[0]["m1"] + "";
                tbxm2.Text = dt.Rows[0]["m2"] + "";
                tbxtotal.Text = dt.Rows[0]["total"] + "";
                tbxavg.Text = dt.Rows[0]["average"] + "";
                tbxresult.Text = dt.Rows[0]["result"] + "";
                

                tbxmsg.Text = "Affected 1 row";
            }
            catch (Exception ex)
            {
                tbxmsg.Text = "Err.: " + ex.Message;
            }
        }

        protected void btncnl_Click(object sender, EventArgs e)
        {
            tbxid.Text = null;

            tbxnae.Text = null;
            
            tbxm1.Text = null;
            tbxm2.Text = null;
            tbxtotal.Text = null;
            tbxavg.Text = null;
            tbxresult.Text = null;

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            uRunDMLQuery("insert");
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            string eid = tbxid.Text;
            uRunDMLQuery("update");
            tbxid.Text = eid;
            btnfind_Click(null, null);
        }

        protected void btnrease_Click(object sender, EventArgs e)
        {
            uRunDMLQuery("delete");
        }

        protected void gvEAList_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }

        public void uRunDMLQuery(String dmLst)
        {
            try
            {
                if (dmLst == "insert")
                {
                    SCmd = new SqlCommand(qryIns, SCnn);
                    SCmd.Parameters.AddWithValue("@name", tbxnae.Text);
                    SCmd.Parameters.AddWithValue("@m1", tbxm1.Text);
                }
                else if (dmLst == "update")
                {
                    SCmd = new SqlCommand(qryUpd, SCnn);
                    SCmd.Parameters.AddWithValue("@eid", tbxid.Text);
                    SCmd.Parameters.AddWithValue("@ename", tbxnae.Text);
                    //SCmd.Parameters.AddWithValue("@esal", tbxsal.Text);
                }
                else if (dmLst == "delete")
                {
                    SCmd = new SqlCommand(qrydel, SCnn);
                    SCmd.Parameters.AddWithValue("@eid", tbxid.Text);

                }

                btncnl_Click(null, null);

                if (SCmd.ExecuteNonQuery() > 0)
                {
                    uRefreshGridView();
                    tbxmsg.Text = "Affected 1 row";
                }

            }
            catch (Exception ex)
            {
                tbxmsg.Text = "Err.: " + ex.Message;
            }
        }

        protected void gvEAList_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbxid.Text = gvEAList.DataKeys[gvEAList.SelectedRow.RowIndex].Value + "";
            btncnl_Click(null, null);

        }

        protected void gvEAList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvEAList.PageIndex = e.NewPageIndex;

            uRefreshGridView();
        }

        
        
    }
}