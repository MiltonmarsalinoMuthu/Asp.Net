﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace cmspprj
{
    public partial class wpebfrmaa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("wpebfrmaa.aspx");
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            Lblinfo.Text = "Info:";

            int cpr = 0;
            int.TryParse(tbxCPR.Text, out cpr);

            int ccr = 0;
            int.TryParse(tbxCCR.Text, out ccr);

            if (cpr > ccr)
            {
                Lblinfo.Text = "Invalid Reading";
                return;
            }

            int cnr = ccr - cpr;
            if (cnr < 0)
            {
                Lblinfo.Text = "Invalid Reading";
                return;
            }
            tbxCNR.Text = cnr+"";

            double puau100 = 0, puau200 = 0, puau400 = 0, puaa400 = 0;

            double taxp = 0, taxa = 0, mc = 0, npay = 0;
            if (ddLCC.SelectedValue == "Agriculture")
            {
                puau100 = 0.25;
                puau200 = 0.50;
                puau400 = 1.50;
                puaa400 = 2.00;

                taxp = 2.5;
                mc = 12.50;
            }
            else if(ddLCC.SelectedValue == "Domestic")
            {
                puau100 = 0.50;
                puau200 = 1.00;
                puau400 = 3.00;
                puaa400 = 6.00;

                taxp = 5.0;
                mc = 25.00;
            }
            else if (ddLCC.SelectedValue == "Commercial")
            {
                puau100 = 1.00;
                puau200 = 2.00;
                puau400 = 6.00;
                puaa400 = 10.00;

                taxp = 7.5;
                mc = 200.00;
            }

            tbxPUAU100.Text = puau100 + "";
            tbxPUAU200.Text = puau200 + "";
            tbxPUAU400.Text = puau400 + "";
            tbxPUAA400.Text = puaa400 + "";

            tbxTaxInP.Text = taxp + "%";
            tbxMC.Text = mc + "";

            double cuu100 = 0, cuu200 = 0, cuu400 = 0, cua400 = 0;

            if (cnr > 400)
            {
                cuu100 = 100;
                cuu200 = 100;
                cuu400 = 200;
                cua400 = cnr - 400;

            }
            else if (cnr > 200)
            {
                cuu100 = 100;
                cuu200 = 100;
                cuu400 = cnr-200;
                
            }
            else if (cnr > 100)
            {
                cuu100 = 100;
                cuu200 = cnr-100;
                
            }
            else if (cnr > 0)
            {
                cuu100 = cnr;
                
            }

            double cuau100 = 0, cuau200 = 0, cuau400 = 0, cuaa400 = 0;

            cuau100 = puau100 * cuu100;
            cuau200 = puau200 * cuu200;
            cuau400 = puau400 * cuu400;
            cuaa400 = puaa400 * cua400;

            taxa = cuaa400 * (taxp / 100);

            npay = cuau100 + cuau200 + cuau400 + cuaa400 + taxa + mc;

            tbxCUU100.Text = cuu100 + "";
            tbxCUU200.Text = cuu200 + "";
            tbxCUU400.Text = cuu400 + "";
            tbxCUA400.Text = cua400 + "";

            tbxCUAU100.Text = cuau100 + "";
            tbxCUAU200.Text = cuau200 + "";
            tbxCUAU400.Text = cuau400 + "";
            tbxCUAA400.Text = cuaa400 + "";

            tbxCUAA400DUP.Text = cuaa400 + "";
            tbxTaxInA.Text = taxa + "";

            tbxNPay.Text = npay + "";
        }
    }
}