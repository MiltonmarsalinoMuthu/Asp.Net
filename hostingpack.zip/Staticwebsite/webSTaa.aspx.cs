﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace cmspprj.Staticwebsite
{
    public partial class webSTaa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btncnl_Click(object sender, EventArgs e)
        {
            tbx10.Text = null;
            tbx20.Text = null;
            tbx30.Text = null;
            tbxid.Text = null;
            tbxname.Text = null;
            tbxnpay.Text = null;
            tbxsal.Text = null;
        }

        protected void btnfind_Click(object sender, EventArgs e)
        {
            int eid = 0;
            int.TryParse(tbxid.Text, out eid);

            string ename = tbxname.Text;

            long sal = 0;
            long.TryParse(tbxsal.Text, out sal);

            double t10=0, t20 =0, t30=0, npay=0;

            if (sal > 1000000)
            {
                t10 = 25000;
                t20 = 100000;
                t30 = (sal - 1000000) * 30.0 / 100;
            }

            else if (sal > 500000)
            {
                t10 = 25000;
                t20 = (sal - 500000) *20.0 / 100;
                
            }
            else if (sal > 250000)
            {
                t10 = (sal - 250000) * 10.0 / 100;
            }

            npay = sal - (t10 + t20 + t30);

            tbx10.Text = (t10 +"");
            tbx20.Text = (t20 + "");
            tbx30.Text = (t30 + "");
            tbxnpay.Text = (npay + "");


        }
    }
}