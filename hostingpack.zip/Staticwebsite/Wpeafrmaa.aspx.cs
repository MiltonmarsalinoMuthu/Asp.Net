﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace cmspprj.Staticwebsite
{
    public partial class Wpeafrmaa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btncnl_Click(object sender, EventArgs e)
        {
            Tbxid.Text = null;
            Tbxname.Text = null;
            Tbxsal.Text = null;
            Tbxhra.Text = null;
            Tbxpf.Text = null;
            Tbxda.Text = null;
            Tbxgpay.Text = null;
            Tbxnpay.Text = null;
        }

        protected void btnfind_Click(object sender, EventArgs e)
        {
            int id = 0;
            int.TryParse(Tbxid.Text, out id);

            string name = Tbxname.Text;

            long sal = 0;
            long.TryParse(Tbxsal.Text, out sal);

            double hra = 0, da = 0, pf = 0, gpay = 0, npay = 0;

            hra = (sal * 20) / 100;
            da = (sal * 15) / 100;
            pf = (sal * 35) / 100;

            gpay = sal + hra + da;
            npay = gpay - pf;

            Tbxhra.Text = (hra + "");
            Tbxda.Text = (da + "");
            Tbxpf.Text = (pf + "");
            Tbxgpay.Text = (gpay + "");
            Tbxnpay.Text = (npay + "");

        }
    }
}