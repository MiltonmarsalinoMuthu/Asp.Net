﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace cmspprj
{
    public partial class wperfrmaa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            tbxrno.Text = null;
            tbxsname.Text = null;
            tbxm1.Text = null;
            tbxm2.Text = null;
            tbxtot.Text = null;
            tbxavg.Text = null;
            Lb1.Text = null;



        }

        protected void btnfind_Click(object sender, EventArgs e)
        {
            int rno = 0;
            int.TryParse(tbxrno.Text, out rno);

            string sname = tbxsname.Text;

            double m1 = 0;
            double.TryParse(tbxm1.Text, out m1);

            double m2 = 0;
            double.TryParse(tbxm2.Text, out m2);

            double tot = m1 + m2;

            double avg = tot / 2;

            bool res = m1 > 34.4 && m2 > 34.4;

            if (res)
            {
                Lb1.Text = "Pass";
            }
            else
            {
                Lb1.Text = "Fail";
            }

            tbxtot.Text = (tot + "");
            tbxavg.Text = (avg + "");
        }
    }
}